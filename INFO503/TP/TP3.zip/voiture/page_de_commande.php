<form action="page_de_commande.php" method="get">
<p> Pour créer votre voiture, veuillez sélectionner : </p>
<input type="text" name="Marque"  placeholder="Marque" required/>
<input type="text" name="Modèle" placeholder="Modèle"required />
<input type="text" name="Motorisation" placeholder="Motorisation"required />
<input type="text" name="Opt1" placeholder="Opt 1"/>
<input type="text" name="Opt2" placeholder="Opt 2" />
<input type="text" name="Opt3" placeholder="Opt 3"/>

<select name="Couleur" id="couleur-selecteur" required>
    <option value="">Couleur </option>
    <option value="Rouge">Rouge</option>
    <option value="Bleu">Bleu</option>
    <option value="Jaune">Jaune</option>
    <option value="vert">Vert</option>
    <option value="violet">Violet</option>
    <option value="rose">Rose</option>
</select>




<p><input type="submit" value="Valider la commande"></p>
</form>

<?php 

include('voiture.php');

    if(isset($_GET['Opt1']) && isset($_GET['Opt2']) && isset($_GET['Opt3'])){
        $array[0]=$_GET['Opt1'];
        $array[1]=$_GET['Opt2'];
        $array[2]=$_GET['Opt3'];
    }
    elseif(isset($_GET['Opt1']) && isset($_GET['Opt2'])){

        $array[0]=$_GET['Opt1'];
        $array[1]=$_GET['Opt2'];
    }
    else{
        $array[0]=$_GET['Opt1'];
    }
$marque=$_GET['Marque'];
$modèle=$_GET['Modèle'];
$motorisation=$_GET['Motorisation'];
$couleur=$_GET['Couleur'];

$ma_commande=new Commande($marque,$modèle,$motorisation,$couleur,$array);
$ma_commande_JSON=json_encode($ma_commande);
/*

    ECRITURE DANS LE TXT

*/

$path = 'commande.txt';
if (isset($_GET['Marque']) && isset($_GET['Modèle']) && isset($_GET['Motorisation'])) {
   $fh = fopen($path,"a+");
   $string = 'Si le client commande :'. $_GET['Marque'].'-'.$_GET['Modèle'].'-'.$_GET['Couleur'] .'-'.$_GET['Motorisation'].'-'.$_GET['Opt1'].'-'.$_GET['Opt2'].'-'.$_GET['Opt3'].'Il obtiendra en JSON : '.$ma_commande_JSON.PHP_EOL;
   fwrite($fh,$string); //Write information to the file
   fclose($fh); //Close the file
}





?>


Bonjour,tu as commandé une <?php echo $_GET['Marque'],"&nbsp", $_GET['Modèle'] ,"&nbsp",$_GET['Couleur'],"&nbsp",$_GET['Motorisation'],"&nbsp",$_GET['Opt1'],"&nbsp",$_GET['Opt2'],"&nbsp",$_GET['Opt3']; ?>