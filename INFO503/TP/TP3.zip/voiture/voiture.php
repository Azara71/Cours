<?php 

class Commande implements JsonSerializable{

    public $marque="";
    public $modèle="";
    public $motorisation="";
    public $couleur="";
    public $options="";

    public function __construct(string $marque,string $modèle,string $motorisation,string $couleur,array $options){

        $this->marque=$marque;
        $this->modèle=$modèle;
        $this->motorisation=$motorisation;
        $this->couleur=$couleur;
        $this->options=$options;
    }

    public function getMarque() : string
    {
        return $this->marque;
    }


    public function jsonSerialize(){
        return [
                'marque' => $this->marque,
                'modèle'=> $this->modèle,
                'motorisation'=>$this->motorisation,
                'couleur'=>$this->couleur,
                'options'=>$this->options,
                
    ];
    }



}


?>