package packagemain;

import java.util.ArrayList;

public class Usine {

	public String NomUsine;
	ArrayList<PlaceDeParking> Parking;
	
	public Usine(String nom_usine,int space) {
		this.NomUsine=nom_usine;
		this.Parking=new ArrayList<PlaceDeParking>(space);
		
		for(int i=0;i<this.Parking.size();i++) {
			this.Parking.get(i).occupe=false;
			this.Parking.get(i).Voiture=null;
			this.Parking.get(i).Numero=i;
		}
	}
	
	
	
	//Creer la voiture
	public Voiture MakeVoiture(String CodeVim,String Marque,String Mod�le,String DateDeFabrication,Element_voiture moteur,ArrayList<Element_voiture>options)
	{
		Voiture vtr=new Voiture(CodeVim,Marque,Mod�le,DateDeFabrication,moteur,options);
		return vtr;
	}
	
	// La mettre sur le parking
	public void Park(Voiture vtr,Usine us) {
		PlaceDeParking pdp=new PlaceDeParking(vtr,false,"a",45);
		us.Parking.add(pdp);
		
	}
	
	// La d�gager du parking
	public void UnPark(Voiture vtr) {

		for(int i=0;i<this.Parking.size();i++) {
			if(this.Parking.get(i).Voiture.CodeVim==vtr.CodeVim) {
				this.Parking.get(i).occupe=false;
				this.Parking.get(i).Voiture=null;

			}
		}
	}
	
	
	public void getPark() {
		for(int i=0;i<this.Parking.size();i++) {
			if(this.Parking.get(i).Voiture!=null) {
			System.out.println(this.Parking.get(i).Voiture.CodeVim);
			}
		}
	}
	
}
