package packagemain;

public class PlaceDeParking {

	public PlaceDeParking(packagemain.Voiture vtr, boolean occupe, String j, int numero) {
		this.Voiture=vtr;
		this.occupe=occupe;
		this.Ligne=j;
		this.Numero=numero;
	}
	public Voiture Voiture;
	public boolean occupe;
	public String Ligne;
	public int Numero;
}
