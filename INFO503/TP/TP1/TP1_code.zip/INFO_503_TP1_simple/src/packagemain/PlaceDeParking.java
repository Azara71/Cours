package packagemain;

public class PlaceDeParking {

	public PlaceDeParking(packagemain.Voiture vtr, boolean occupe, int numero) {
		this.Voiture=vtr;
		this.occupe=occupe;
		this.Numero=numero;
	}
	public Voiture Voiture;
	public boolean occupe;
	public int Numero;
}
