package packagemain;

import java.util.ArrayList;

public class Parking {
	
	public String nom_park;
	ArrayList<PlaceDeParking> pdparking;
	
	public Parking(String nom_park,int place) {
		 this.pdparking=new ArrayList<PlaceDeParking>(place);
		 this.nom_park=nom_park;
	}
}
