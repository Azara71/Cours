package packagemain;

import java.util.ArrayList;

public class test {

	public static void main(String[] args) {

		Element_voiture moteur_1=new Element_voiture("moteur_1",5);
		ArrayList<Element_voiture> options = null;
		Usine usine= new Usine("mon_usinedetest",50);
		Voiture mavoiture=new Voiture();
		Voiture mavoiture_2=new Voiture();

		mavoiture=usine.MakeVoiture("848415", "Opel", "Corsa", "14/07/2023", moteur_1, options);
		mavoiture_2=usine.MakeVoiture("51545455", "Opel", "Corsa", "14/07/2023", moteur_1, options);

		System.out.println(mavoiture.getVoiture());
		usine.Park(mavoiture,usine,1);
		usine.Park(mavoiture_2,usine,1);

		usine.getPark();
		usine.UnPark(mavoiture);
		usine.getPark();



		}

}
