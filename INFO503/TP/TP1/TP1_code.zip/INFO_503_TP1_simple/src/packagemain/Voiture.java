package packagemain;
import java.util.ArrayList;

public class Voiture {
	
	public String CodeVim;
	public String Marque;
	public String Mod�le;
	public String DateDeFabrication;
	public Element_voiture moteur;
	public ArrayList<Element_voiture> options;

	
	public Voiture(String CodeVim,String Marque,String Mod�le,String DateDeFabrication,Element_voiture moteur,ArrayList<Element_voiture>options) {
		this.CodeVim=CodeVim;
		this.Marque=Marque;
		this.Mod�le=Mod�le;
		this.DateDeFabrication=DateDeFabrication;
		this.moteur=moteur;
		this.options=options;
	}
	public Voiture() {
	}
	public String getVoiture() {
		return this.CodeVim;
	}
}
