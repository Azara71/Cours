package packagemain;

import java.util.ArrayList;

public class Usine {

	public String NomUsine;
	public Parking park;

	public Usine(String nom_usine,int space) {
		this.NomUsine=nom_usine;
		this.park=new Parking(nom_usine,space);
		this.park.nom_park=nom_usine;
		for(int i=0;i<this.park.pdparking.size();i++) {
			this.park.pdparking.get(i).occupe=false;
			this.park.pdparking.get(i).Voiture=null;
			this.park.pdparking.get(i).Numero=i;
		}
	}
	
	
	
	public Voiture MakeVoiture(String CodeVim,String Marque,String Mod�le,String DateDeFabrication,Element_voiture moteur,ArrayList<Element_voiture>options)
	{
		Voiture vtr=new Voiture(CodeVim,Marque,Mod�le,DateDeFabrication,moteur,options);
		return vtr;
	}
	
	// La mettre sur le parking
	public void Park(Voiture vtr,Usine us,int numero) {
			PlaceDeParking pdp=new PlaceDeParking(vtr,true,numero);
			this.park.pdparking.add(pdp);
		
			}
	
	// La d�gager du parking
	public void UnPark(Voiture vtr) {

		for(int i=0;i<this.park.pdparking.size();i++) {
			if(this.park.pdparking.get(i).Voiture.CodeVim==vtr.CodeVim) {
				this.park.pdparking.get(i).occupe=false;
				this.park.pdparking.get(i).Voiture=null;

			}
		}
	}
	
	
	public void getPark() {
		boolean presence=false;
		for(int i=0;i<this.park.pdparking.size();i++) {
			if(this.park.pdparking.get(i).Voiture!=null) {
			System.out.println(this.park.pdparking.get(i).Voiture.CodeVim);
			presence=true;
			}
		}
		if(presence==false) {
			System.out.println("Plus de voiture sur le parking.");
		}

	}
	
}
