package packagemain;

public class Element_voiture {

	
	public String nom_element;
	public int nombre;
	
	public Element_voiture(String nom_elem,int nb) {
		this.nom_element=nom_elem;
		this.nombre=nb;
}
}
