package packagemain;

import org.json.JSONObject;

public class Element_voiture {

	
	public String nom_element;
	public int nombre;
	
	public Element_voiture(String nom_elem,int nb) {
		this.nom_element=nom_elem;
		this.nombre=nb;
}
	
    @Override
    public String toString() {
        return nom_element;
    }


	public JSONObject toJSON() {
		JSONObject json=new JSONObject();
		json.put("nom_element", this.nom_element);
		json.put("nombre",this.nombre);
		return json;
	}
	public static Element_voiture fromJSON(String source) {
		JSONObject Element_voitureJson=new JSONObject(source);
		String nom_element=Element_voitureJson.getString("nom_element");
		int nb_element=Element_voitureJson.getInt("nombre");
		return new Element_voiture(nom_element,nb_element);
	}
	
	
    
}
