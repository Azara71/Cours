package packagemain;
import java.util.HashMap;
import java.util.Map.Entry;

import org.json.JSONObject;



public class Voiture implements Comparable {
	
	public String CodeVim;
	public String Marque;
	public String Mod�le;
	public String DateDeFabrication;
	public Element_voiture moteur;
	public  HashMap<Integer,Element_voiture>options;

	
	public Voiture(String CodeVim,String Marque,String Mod�le,String DateDeFabrication,Element_voiture moteur,HashMap<Integer, Element_voiture> options) {
		this.CodeVim=CodeVim;
		this.Marque=Marque;
		this.Mod�le=Mod�le;
		this.DateDeFabrication=DateDeFabrication;
		this.moteur=moteur;
		this.options=options;
	}
	public Voiture() {
	}
	public Voiture(String Marque) {
		this.Marque=Marque;
	}
	public String getVoiture() {
		return this.CodeVim;
	}
	
	public JSONObject toJson() {
	  	JSONObject json=new JSONObject();
    	json.put("CodeVim", this.CodeVim);
    	json.put("Marque",this.Marque);
    	json.put("Mod�le", this.Mod�le);
    	json.put("DateDeFabrication", this.DateDeFabrication);
    	json.put("moteur",this.moteur.toJSON());
    	
    	for(Entry<Integer, Element_voiture> entry: this.options.entrySet()) {
    		int key = entry.getKey();
    		Element_voiture value=entry.getValue();
    		json.put("opt"+key, value.toJSON());
    	}
    	json.put("nb_opt",this.options.size());
    	return json;
	}
	
	 public static Voiture fromJSON(String source) {
	    	JSONObject VoitureJson=new JSONObject(source);
	    	String CodeVim=VoitureJson.getString("CodeVim");
	    	String Marque=VoitureJson.getString("Marque");
	    	//String CodeVim,String Marque,String Mod�le,String DateDeFabrication,Element_voiture moteur,HashMap<Integer, Element_voiture> options;
	    	String Mod�le=VoitureJson.getString("Mod�le");
	    	String DateDeFabrication=VoitureJson.getString("DateDeFabrication");
	    	Element_voiture moteur=Element_voiture.fromJSON(VoitureJson.getJSONObject("moteur").toString());
	    	int nb_opt=VoitureJson.getInt("nb_opt");
	    	HashMap<Integer,Element_voiture> coptions=new HashMap<Integer,Element_voiture>();
	    	
	    	for(int i=1;i<=nb_opt;i++) {
	    		Element_voiture options_tempo=Element_voiture.fromJSON(VoitureJson.getJSONObject("opt"+i).toString());
	    		coptions.put(i,options_tempo);
	    	
	    	}
	    	
	 	   return new Voiture(CodeVim,Marque,Mod�le,DateDeFabrication,moteur,coptions);
	 }
	
	 @Override
	    public String toString() {
	        return CodeVim +","+Marque+","+Mod�le+","+DateDeFabrication+","+moteur+","+options ;
	    }
	 @Override
	public int compareTo(Object o) {
		Voiture voituretocompare=(Voiture) o;
		if(CodeVim==voituretocompare.CodeVim && Marque==voituretocompare.Marque && Mod�le==voituretocompare.Mod�le && DateDeFabrication==voituretocompare.DateDeFabrication && moteur==voituretocompare.moteur ) {
			return 1;
		}
		else {
			System.out.println(voituretocompare.toString());
			return 0;
		}
		
	
	}
	 
	 
/*
 * public static Auteur fromJSON(String source) {
    	JSONObject auteurJSON=new JSONObject(source);
    	String nom=auteurJSON.getString("nom");
    	String date=auteurJSON.getString("dateNaissance");
    	return new Auteur(nom,date);
    }
 */
	    	/*
	    	 * for(int i=0;i<compt;i++) {
	    		Livre livre=Livre.fromJSON(buJson.getJSONObject("livre"+i).toString());
	    		bu_tempo.ajouterLivre(livre);
	    	}
	    	*/
	    	
	    }
	

