package packagemain;

import java.util.HashMap;
import org.json.JSONObject;


public class test {

	public static void main(String[] args) {

		Element_voiture moteur_1=new Element_voiture("moteur_1",1);
		Element_voiture opt1=new Element_voiture("Mon �l�ment",1);
		Element_voiture opt2=new Element_voiture("akpskdkpaspk",1);
		HashMap<Integer, Element_voiture> options = new HashMap<Integer,Element_voiture>();
		options.put(1, opt1);
		options.put(2, opt2);
		Usine usine= new Usine("mon_usinedetest");
		Voiture mavoiture=new Voiture();
		Voiture mavoiture_2=new Voiture();
		mavoiture_2=usine.MakeVoiture("4155151", "Opel", "Corsa", "14/07/2023", moteur_1, options);
		mavoiture=usine.MakeVoiture("848415", "Opel", "Corsa", "14/07/2023", moteur_1, options);
/*
		System.out.println(mavoiture.getVoiture());
		usine.Park(mavoiture,usine);
		String source=mavoiture.toJson().toString();

		
		System.out.println(source);

		usine.Park(mavoiture_2,usine);
		usine.getPark();
		System.out.println(usine.getVoiture(0));

		usine.UnPark(mavoiture);
		usine.UnPark(mavoiture_2);
		System.out.println(usine.getPark());
*/
		//ESSAI ELEMENT
		String test = opt1.toJSON().toString();
		System.out.println("test de la serialisation d'un �lement.");
		System.out.println("On r�cup�re du Json:"+Element_voiture.fromJSON(test));
		
		
		// ESSAI VOITURE
		String test_voiture = mavoiture.toJson().toString();
	/*	System.out.println(test_voiture);*/
		System.out.println("test de la s�rialisation de Voiture ");
		System.out.println("On r�cup�re du Json:"+Voiture.fromJSON(test_voiture));
		// ESSAI PLACE DE PARKING
		System.out.println("test de la serialisation de pdp");
		PlaceDeParking pdp_test=new PlaceDeParking(mavoiture,true,1);
		String source_pdp=pdp_test.toJson().toString();
		System.out.println("On r�cup�re du Json:"+PlaceDeParking.fromJson(source_pdp));
		usine.Park(mavoiture_2,usine);
		usine.Park(mavoiture,usine);
		//System.out.println(usine.ToString());
	
		// ESSAI USINE

		String test_usine=usine.toJson().toString();
		System.out.print("test de la serialisation d'usine\n");
		System.out.println("On r�cup�re du Json :"+Usine.fromJson(test_usine));
		System.out.println("test de comparaison Voiture :"+mavoiture_2.compareTo(Voiture.fromJSON(test_voiture)));
		// Essai de sauvegarde et de chargement
		
		usine.Save();
		System.out.println("Chargement de l'usine  ");

		System.out.println("On r�cup�re l'usine : \n"+ usine.load().toString());

	}

}
