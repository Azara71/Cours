package packagemain;

import org.json.JSONObject;


public class PlaceDeParking {


	public Voiture Voiture;
	public boolean occupe;
	public int Numero;
	
	public PlaceDeParking(packagemain.Voiture vtr, boolean occupe , int numero) {
		this.Voiture=vtr;
		this.occupe=occupe;
		this.Numero=numero;
	}
	
	public JSONObject toJson() {
		JSONObject PdpJson=new JSONObject();
		PdpJson.put("Voiture", this.Voiture.toJson());
		PdpJson.put("occupe",this.occupe);
		PdpJson.put("Numero", this.Numero);
		return PdpJson;
	}
	
	public static PlaceDeParking fromJson(String source) {
		JSONObject PlaceDeParkingJson=new JSONObject(source);
		Voiture vtr=packagemain.Voiture.fromJSON(PlaceDeParkingJson.getJSONObject("Voiture").toString());
		boolean occupe=PlaceDeParkingJson.getBoolean("occupe");
		int numero=PlaceDeParkingJson.getInt("Numero");
		return new PlaceDeParking(vtr,occupe,numero);
		
		
	}
	@Override
	public String toString() {
		String aretourner;
		aretourner="Place numero :"+Numero+",Voiture:"+Voiture.toString();
		return aretourner;
	}
	
		
	}

