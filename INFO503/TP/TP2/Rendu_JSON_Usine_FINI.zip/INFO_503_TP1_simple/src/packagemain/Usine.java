package packagemain;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map.Entry;

import org.json.JSONObject;




public class Usine {

	public String NomUsine;
    private HashMap<Integer,PlaceDeParking> Parking;
	int compt=0;
	
	
	public Usine(String nom_usine) {
		this.NomUsine=nom_usine;
		this.Parking=new HashMap<Integer,PlaceDeParking>();
		
	}
	//Constructeur pour le fromJson
	public Usine(String nom_usine,HashMap<Integer,PlaceDeParking>Park) {
		this.NomUsine=nom_usine;
		this.compt=Park.size();
		this.Parking=Park;
		
	}
	
	
	public Voiture MakeVoiture(String CodeVim,String Marque,String Mod�le,String DateDeFabrication,Element_voiture moteur,HashMap<Integer, Element_voiture> options)
	{
		Voiture vtr=new Voiture(CodeVim,Marque,Mod�le,DateDeFabrication,moteur,options);
		return vtr;
	}
	
	public int Park(Voiture vtr,Usine us) {
		PlaceDeParking pdp=new PlaceDeParking(vtr,false,compt);
		Parking.put(compt, pdp);
		return compt++;
	}
	public void UnPark(Voiture vtr) {

		for(int i=0;i<this.Parking.size();i++) {
			if(this.Parking.get(i).Voiture.CodeVim==vtr.CodeVim) {
				this.Parking.get(i).occupe=false;
				this.Parking.get(i).Voiture=null;
				this.compt--;
			}
		}
	}
	
	
	public HashMap<Integer, PlaceDeParking> getPark() {
		for(int i=0;i<this.Parking.size();i++) {
			if(this.Parking.get(i).Voiture!=null) {
				return this.Parking;
			}
		}
			
		return null;
	}
		public Voiture getVoiture(int i) {
				Voiture resultat=null;
					if(Parking.containsKey(i)) {
						resultat=Parking.get(i).Voiture;
					}
				return resultat;
		}
	
		
    public JSONObject toJson() {
    	JSONObject usineJson = new JSONObject();
    	usineJson.put("NomUsine",NomUsine);
    	usineJson.put("compteur", compt);
    	for(Entry<Integer, PlaceDeParking> entry : this.Parking.entrySet()) {
    		int key = entry.getKey();
    		PlaceDeParking value=entry.getValue();
    		usineJson.put("Pdp"+key, value.toJson());
    	}
    
    	
    	return usineJson;
    	
    }
    
    public static Usine fromJson(String source) {
    	JSONObject usineJson = new JSONObject(source);
    	int compteur=usineJson.getInt("compteur");
    	String NomUsine=usineJson.getString("NomUsine");
        HashMap<Integer,PlaceDeParking> Park = new HashMap<Integer,PlaceDeParking>();

    	for(int i=0;i<compteur;i++) {
    		PlaceDeParking pdp=PlaceDeParking.fromJson(usineJson.getJSONObject("Pdp"+i).toString());
    		Park.put(i, pdp);
    	}
    	
    	

    	
    	return new Usine(NomUsine,Park);
    	
    }
    @Override
    public String toString() {
		  
		if(Parking.size()==0) {
			return "Le Parking est vide";
		}
		String contenu_Usine = "Nom de l'usine :"+NomUsine+"\n";
		for(int cle : Parking.keySet()) {
			contenu_Usine+="Place numero : "+cle+","+Parking.get(cle).toString()+"\n";
		}
		
		return contenu_Usine;
	}
    
    
    public void Save() {
    	 try {

    		   String content = this.toJson().toString();

    		   File file = new File(NomUsine+".txt");

    		   // cr�er le fichier s'il n'existe pas
    		   if (!file.exists()) {
    		    file.createNewFile();
    		   }

    		   FileWriter fw = new FileWriter(file.getAbsoluteFile());
    		   BufferedWriter bw = new BufferedWriter(fw);
    		   bw.write(content);
    		   bw.close();

    		   System.out.println("Usine : "+NomUsine+" sauvegard�e dans le fichier : "+NomUsine+".txt");

    		  } catch (IOException e) {
    		   e.printStackTrace();
    		  }
    		 }
    

public Usine load() {
	File f=new File(NomUsine+".txt");
    try {
       BufferedInputStream in = new BufferedInputStream(new FileInputStream(f));
       StringWriter out = new StringWriter();
       int b;
       while ((b=in.read()) != -1)
           out.write(b);
       out.flush();
       out.close();
       in.close();
       Usine usn=Usine.fromJson(out.toString());

       return usn; 
    }
    catch (IOException ie)
    {
         ie.printStackTrace(); 
    }
	return null;
}
    		
	
	
		
		        
		     
}
