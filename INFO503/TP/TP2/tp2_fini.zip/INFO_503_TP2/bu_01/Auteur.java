package bu_01;

import org.json.JSONObject;
import org.json.JSONPropertyName;

/**
 * Classe représentant un auteur de livre.
 * @author Cyril Rabat
 */
public class Auteur {

    private String nom;
    private String dateNaissance;
   
    /**
     * Crée un auteur avec un nom et une date de naissance.
     * @param nom le nom
     * @param dateNaissance la date de naissance
     */
    public Auteur(String nom, String dateNaissance) {
        this.nom = nom;
        this.dateNaissance = dateNaissance;
    }
    
    /**
     * Retourne le nom.
     * @return le nom
     */
    public String getNom() {
        return nom;
    }
    
    /**
     * Retourne la date de naissance.
     * @return la date de naissance
     */
    @JSONPropertyName("dateNaissance")
	public String getNaissance(){
	return this.dateNaissance;
}
    public String dateNaissance() {
        return dateNaissance;
    }
    public JSONObject toJSON() {
    	JSONObject json=new JSONObject();
    	json.put("nom", this.nom);
    	json.put("dateNaissance",this.dateNaissance);
    	return json;
    }
    
    public static Auteur fromJSON(String source) {
    	JSONObject auteurJSON=new JSONObject(source);
    	String nom=auteurJSON.getString("nom");
    	String date=auteurJSON.getString("dateNaissance");
    	return new Auteur(nom,date);
    }
    
    /**
     * Convertit l'auteur en chaîne de caractères.
     * @return une chaîne de caractères
     */
    @Override
    public String toString() {
        return nom + ", " + dateNaissance;
    }

}