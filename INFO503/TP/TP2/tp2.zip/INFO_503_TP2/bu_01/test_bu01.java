package bu_01;

import org.json.JSONObject;

public class test_bu01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Auteur auteur=new Auteur("Victor Hugo","26/02/1802");
		System.out.println(new JSONObject(auteur));
		System.out.println(auteur.toJSON());
		String source=auteur.toJSON().toString();
		System.out.println(Auteur.fromJSON(source));
		
		Livre livre=new Livre("Le livre de test", auteur);
		String source_2=livre.toJSON().toString()	;
		System.out.println(Livre.fromJSON(source_2));
		BU Biblio=new BU();
		Biblio.ajouterLivre(livre);
	}

}
