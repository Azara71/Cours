package pokemon;

import java.io.IOException;
import java.util.Scanner;

public class main_test {
	public static void main(String[] arg) throws IOException {
	
		System.out.println("Donnez votre nom");
		Scanner sc=new Scanner(System.in);
		String nom_pokemon_generated=sc.nextLine();
		Pokemon mon_poke=PokemonFactory.makePokemon(nom_pokemon_generated);
		if(mon_poke!=null) {
		System.out.println(mon_poke.getType_1());
		}
	}
}
