package pokemon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;

public class PokemonFactory {
 
	public static Pokemon makePokemon(String nom) throws IOException{

		File f = new File("resources/BDD_Poke.txt");
		BufferedReader reader = new BufferedReader(new FileReader(f));
		String line = null;
		String line_poke_trouvee = null;
		String element_tempo[]=null;
		boolean present = false;
		// Tant qu'on est pas � la fin du .txt, ou qu'on a pas vu le pok�mon
		while ((line = reader.readLine()) != null && present !=true) {
			
			if(present==false) {
				// Pour sauvegarder la derni�re ligne pass�e, � cause de line.contains qui passe � la fin de la ligne
				line_poke_trouvee=line;
			}
						
			if (line.contains(nom)==true) {
				present=true;
				/* Sert � convertir les �l�ments de la ligne, s�par� par ;, dans un tableau*/
				element_tempo=line_poke_trouvee.split(";");
				
				
				/*Sert � tester
				System.out.print(element_tempo[0]);
				System.out.print("\nDe type "+element_tempo[1]);
				System.out.print("\nDe type "+element_tempo[2]);
				System.out.print("\nAvec comme nb d'HP "+element_tempo[3]);
				*/

				return new Pokemon(nom,element_tempo[1],element_tempo[2],element_tempo[3]);

				
			}
			else {
				present=false;
			}
		}
		
		if(present!=true) {
			
			System.out.println("Le pok�mon ne figure pas dans la base de donn�e");

		}
		return null;
		
	
	};
}
