package pokemon;

import pokemon.Caracteristique.Type;

public class Pokemon extends Caracteristique {

	String nom;
public Pokemon(String nom,String type_1,String type_2,String PointsDeVie) {
		
		this.nom=nom;
		this.Type_1=Type.valueOf(type_1);
		this.Type_2=Type.valueOf(type_2);
		this.PointsDeVie=Integer.parseInt(PointsDeVie);

	}
public String getNom() {
	return(nom);
	}
public String getType_1() {
	return (Type_1.toString());
}
}

