package pokemon;


public abstract class Caracteristique {
	public enum Type{ACIER,
		DRAGON,
		ELECTRIQUE,
		FEU,
		INSECTE,
		PLANTE,
		PSY,
		SOL,
		TENEBRES,
		COMBAT,
		EAU,
		FEE,
		GLACE,
		NORMAL,
		POISON,
		ROCHE,
		SPECTRE,
		VOL
		};
	
	
	protected int PointsDeVie;
	protected Type Type_1;
	protected Type Type_2;
	private int Experience;
	private String Attq1;
	private String Attq2;
	private String Attq3;
	private String Attq4;
	
	private String Talent_1;
	private String Talent_2;
	
}
