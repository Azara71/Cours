public class Test {

    public static void main(String[] args) {

        Codeur codeur =new Codeur();
        MonCodeur moncodeur=new MonCodeur();
        String MessCode;
        String tatata="bibou";
        String chaine_code;

        try {
        
            chaine_code=moncodeur.decorateur_encode(tatata, codeur);
            //System.out.print(chaine_code);
            System.out.print(moncodeur.decorateur_decode(chaine_code,codeur));
        
        }
        catch(Exception e) {
            
            System.out.print("Erreur");
        }
        
    }

}