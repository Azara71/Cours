public class MonCodeur{
    public String str_1;
    public String str_2;



    public String decorateur_encode(String s,Codeur codeur){
        // Transformation de string en string builder pour utiliser reverse() 
        StringBuilder strb = new StringBuilder(s);
        str_1 = strb.reverse().toString();
        str_2=str_1.concat(s);
        str_1=str_2.concat(str_2);
        String t;
        
        // Etape pr�c�dente :On inverse la cha�ne, on concataine l'inversion avec la cha�ne.
        try {
            
            return(codeur.encode(str_1));


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    
    //Decorateur de d�code
    public String decorateur_decode(String s,Codeur codeur) {
        try {
            // Utilisation de decode classique
            s=codeur.decode(s);
            // Couche suppl�mentaire
            s.substring(0, s.length()/4);
        } catch (Exception e) {

            e.printStackTrace();
        }
        return s;
        
    }
    
    
        
        
    
} 